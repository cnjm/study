let img = document.querySelector('#img');
if (img) {
    //...
    // (<HTMLImageElement>img).src;

    (img as HTMLImageElement).src;
}