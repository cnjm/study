// function css(ele: Element, attr: string, value: string|number) {
//     // ...
// }

// let box = document.querySelector('div');
// if (box) {
//     css( box, 'width', '100px' );
//     css( box, 'opactiy', 1 );
//     css( box, 'opactiy', [1,2] );
// }