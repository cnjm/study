// function setPosition(ele: Element, direction: 'left' | 'top' | 'right' | 'bottom') {
//     //
// }

// let box = document.querySelector('div');
// if (box) {
//     setPosition(box, 'left');
//     setPosition(box, 'a');
// }
