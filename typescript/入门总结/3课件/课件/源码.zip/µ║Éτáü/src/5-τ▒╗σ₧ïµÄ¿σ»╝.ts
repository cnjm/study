// let a: string = 'kaikeba';

// let a = '开课吧';

// function fn(a = 1) {
//     if (true) {
//         return 'kaikeba';
//     } else {
//         return 100;
//     }
// }