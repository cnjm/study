// function fn(): void {
//     // return null;
// }
// let v = fn();