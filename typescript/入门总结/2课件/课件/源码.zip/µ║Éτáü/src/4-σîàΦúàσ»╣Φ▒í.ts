let a: string;
a = '1';
a = new String('1');


let b: String;
b = new String('1');
b = '1';