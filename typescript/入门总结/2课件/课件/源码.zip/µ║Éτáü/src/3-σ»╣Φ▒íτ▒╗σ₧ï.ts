// let a: Object = {};
// let arr: Array<number> = [1,2,3];
// let d1: Date = new Date();

// let user: {username:string, age:number} = {
//     username: 'zmouse',
//     age: 35
// }
// user.gender;

// interface Person {
//     username: string;
//     age: number;
// }

// let user: Person = {
//     username: 'zMouse',
//     age: 35
// }
// let user1: Person = {
//     username: 'MT',
//     age: 30
// }

// let user2 = Person;


// class Person {
    
//     constructor(public username: string, public age: number) {

//     }
// }

// let user: Person = new Person('zMouse', 35);


// interface AjaxOptions {
//     url: string;
//     method: string;
// }

// function ajax(options: AjaxOptions) {}

// ajax({
//     url: '',
//     method: 'get'
// });