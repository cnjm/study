// let a: null;
// let b: undefined;

// a = 1;

// let c: number;

// c = undefined;

// let d: number;
// let e;


// let a:number;
// a = null;
// // ok（实际运行是有问题的）
// a.toFixed(1);

// let ele = document.querySelector('div');
// if (ele) {
//     ele.style.display = 'none';
// }
