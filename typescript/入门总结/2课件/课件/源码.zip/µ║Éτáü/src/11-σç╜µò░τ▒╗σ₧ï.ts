function fn1(x: number, y: number): number {
    return x + y;
}

let v: number = fn1(1, 2);