// let title: string = '开课吧';
// let n: number = 1;
// let isOk: boolean = true;