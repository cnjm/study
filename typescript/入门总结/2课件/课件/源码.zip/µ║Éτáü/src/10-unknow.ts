// let c: any = '开课吧';

// let d: number = 1;

// d.toFixed(1);

// d = c;
// d.toFixed(1);


// let c: unknown = '开课吧';

// let d: number = 1;

// d.toFixed(1);

// d = c;
// d.toFixed(1);

// let c: any;
// c.a;

// let d: unknown;
// d.a;