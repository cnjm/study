// let arr1: Array<number> = [1,2,3];
// arr1.push(100);
// arr1.push('开课吧');


// let arr2: string[] = ['a', 'b', 'c'];
// arr2.push('开课吧');
// arr2.push(100);