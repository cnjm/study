// // let a: any;
// // a = 1;

// // let b: number;
// // b = a;

// // a.ab;

function fn(a: string) {
    a.indexOf('a', 1);
}