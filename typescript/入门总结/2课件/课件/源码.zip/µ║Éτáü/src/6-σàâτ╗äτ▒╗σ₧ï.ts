let data1: [string, number] = ['开课吧', 1];
data1.push(110);
data1.push(true);