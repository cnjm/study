function sort( items: Array<any>, order: 'desc'|'asc' = 'desc' ) {
    // ...
}

sort([1,2,3], 'asc');
sort([1,2,3]);

sort([1,2,3], 'kaikeba');