let str: string = '开课吧';

let data = {
    x: 1,
    y: 2,
    z: 3,
}